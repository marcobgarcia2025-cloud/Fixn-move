# Fixn|Move

Official website for **Fixn|Move** — Asheboro, NC.

One call. Many solutions. Moving, junk removal & demolition, appliance installation, and carpentry.

- 📞 Text or call: 336-953-1981 (Se Habla Español)
- ✉️ Email: fixnmove26@gmail.com
- 📍 Located in Asheboro, NC · Serving the Triad
- 📘 Facebook: https://www.facebook.com/share/18pdqyG27w/?mibextid=wwXIfr

## About this site
A single self-contained `index.html` file (no build step, no dependencies). Features:
- Services: appliance installation, junk removal/demolition, moving, carpentry/decks
- Self-serve **Free Quote scheduler** that adds the appointment to the visitor's Google Calendar
- Mobile-friendly, animated header, no pricing displayed

## Run locally
Just open `index.html` in any browser.

## Deploy with GitHub Pages
1. Push this repo to GitHub.
2. Repo **Settings → Pages → Source: Deploy from a branch → main → /(root)** → Save.
3. Your site goes live at `https://<username>.github.io/Fixn-move/`.
